//
//  ViewController.swift
//  DONA
//
//  Created by UNAM-Apple12 on 25/10/22.
//

import UIKit

class ViewController: UIViewController {


    
    @IBOutlet weak var img1: UIImageView!
    
    @IBOutlet weak var img3: UIImageView!
    
    @IBOutlet weak var img4: UIImageView!
    
    @IBOutlet weak var img5: UIImageView!
    @IBOutlet weak var img6: UIImageView!
    @IBOutlet weak var img7: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        
        img3.layer.borderWidth = 1
        img3.layer.masksToBounds = false
        img3.layer.borderColor = UIColor.black.cgColor
       img3.layer.cornerRadius = img3.frame.height/2
        img3.clipsToBounds = true

        
        img4.layer.borderWidth = 1
        img4.layer.masksToBounds = false
        img4.layer.borderColor = UIColor.black.cgColor
       img4.layer.cornerRadius = img4.frame.height/2
        img4.clipsToBounds = true
        
        
        img5.layer.borderWidth = 1
        img5.layer.masksToBounds = false
        img5.layer.borderColor = UIColor.black.cgColor
       img5.layer.cornerRadius = img5.frame.height/2
        img5.clipsToBounds = true
        
        
        img6.layer.borderWidth = 1
        img6.layer.masksToBounds = false
        img6.layer.borderColor = UIColor.black.cgColor
       img6.layer.cornerRadius = img6.frame.height/2
        img6.clipsToBounds = true
        
        
        img7.layer.borderWidth = 1
        img7.layer.masksToBounds = false
        img7.layer.borderColor = UIColor.black.cgColor
       img7.layer.cornerRadius = img7.frame.height/2
        img7.clipsToBounds = true
        
        
        
        img1.layer.borderWidth = 1
        img1.layer.masksToBounds = false
        img1.layer.borderColor = UIColor.black.cgColor
       img1.layer.cornerRadius = img1.frame.height/2
        img1.clipsToBounds = true            // Do any additional setup after loading the view.
    }


}

