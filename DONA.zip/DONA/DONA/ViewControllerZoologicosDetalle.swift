//
//  ViewControllerZoologicosDetalle.swift
//  DONA
//
//  Created by UNAM-Apple12 on 26/10/22.
//

import UIKit

class ViewControllerZoologicosDetalle: UIViewController {

    var ZoologicoSeleccionado : Zoologico?
    
    @IBOutlet weak var imgZoologico: UIImageView!
    
    @IBOutlet weak var labelNombre: UILabel!
    
    @IBOutlet weak var labelUsos: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        labelNombre.text = ZoologicoSeleccionado?.nombre
        labelUsos.text = ZoologicoSeleccionado?.Usos
        imgZoologico.image = ZoologicoSeleccionado?.imagen
        
        
        
        
        
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
