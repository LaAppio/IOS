//
//  TableViewCellSantuarios.swift
//  DONA
//
//  Created by UNAM-Apple12 on 24/11/22.
//

import UIKit

class TableViewCellSantuarios: UITableViewCell {
    
    @IBOutlet weak var labelSantuario: UILabel!
    
    @IBOutlet weak var imagensantuario: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
