//
//  TableViewControllerReservas.swift
//  DONA
//
//  Created by UNAM-Apple12 on 24/11/22.
//

import UIKit

struct Reserva {
    var nombre: String
    var usos: String
    var imagen: UIImage
}

class TableViewControllerReservas: UITableViewController {
    
    var Reservaseleccionada : Reserva?
    var listaReserva: [Reserva] = [
    Reserva(nombre: "Parque Nacional Cañón del Sumidero", usos: "El Cañón del Sumidero registra varios microclimas donde viven e interactúan la fauna y la vegetación, con especies endémicas como la Salamandra Lengua Hongueada, la Cuija Mexicana, el Chupaflor Canelo, el Sapo Jaspeado, la Mojarra de Chiapa de Corzo y el Encino Enano", imagen: UIImage (named: "Cañon")!),
    Reserva(nombre: "Parque Nacional Bahía de Loreto", usos: "Este destino, ubicado Baja California Sur, tiene cinco islas llenas de biodiversidad,donde habita el mamífero más grande del mundo, la ballena azul, y otras especies como la ballena jorobada, orcas, delfines, lobos marinos y aves.", imagen: UIImage (named: "loreto")!)]

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return listaReserva.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Reserva", for: indexPath) as! TableViewCellReserva
        
        let Reserva = listaReserva[indexPath.row]
        cell.labelReservas.text = Reserva.nombre
        cell.imagenReservas.image = Reserva.imagen
        // Configure the cell...

        return cell
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
        
        

     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) { print(indexPath.row)
                
        Reservaseleccionada = listaReserva[indexPath.row]
             performSegue(withIdentifier: "Reserva", sender: nil)
    }
      func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let siguienteEscena2 = segue.destination as! ViewControllerReservaDetalle
          if segue.identifier == "SegueReservas"{
              siguienteEscena2.ReservaRecibida = Reservaseleccionada
              
          }
            

}
    }}
