//
//  TableViewControllerRecetas.swift
//  prototipo final
//
//  Created by Laboratorio UNAM-Apple4 on 27/10/22.
//

import UIKit

struct Receta {
    var nombre: String
    var tiempo: String
    var platillo : String
    var ingredientes : String
    var preparación : String
    var imagen: UIImage
    
    
}

class TableViewControllerRecetas: UITableViewController {
 
    var RecetaSeleccionada : Receta?
    
    var listaRecetas : [Receta] = [
        Receta(nombre:"Desayunos",tiempo:"Tiempo de preparación: 45 min", platillo: "Pancakes de zanahoria", ingredientes : "1/2 taza de zanahoria rallada, 1/2 tza de claras de huevo, 1/2 tza de hojuelas de avena, 1 cucharada de canela en polvo, Esencia de vainilla (al gusto), polvo para hornear, 1/2 plátano, Stevia, 2 cucharadas de yogurt griego, 2 cucharaditas de aceite de oliva, miel", preparación: "1. En una licuadora poner todos los ingredientes (excepto el yogurt, la miel y el aceite). 2. Licuar por 2 minutos hasta que se integran todos los ingredientes. 3. Llevar a un sartén engrasado con el aceite de oliva, formar los pancakes y cocer a fuego lento por ambos lados. 4. Servir en un plato y agregarle los toppings de tu preferencia: miel y yogurt griego", imagen: UIImage(named: "desayunos")!),
        Receta(nombre: "Comidas",tiempo: "Tiempo de preparación: 65 min", platillo: "Pollo al curry", ingredientes : "120 gr de pollo cortado en cubitos, 1 cebolla, 1 jitomate, 1 zanahoria, 1/2 calabacin, 1 cda de curry, 1 ajo, 1/2 chile rojo, Perejil, 1 trocito de jengibre picado, 50 ml de leche de coco, 2 cucharaditas de aceite de oliva, pizca de sal, 1/2 taza de arroz",preparación: "1. Sazonar el pollo. 2. Poner en un sarten con 1 cucharadita de aceite, la cebolla, ajo, zanahoria y calabacín, dejar por 2 minutos después de añadir el pollo, y el jengibre y dejar todo hasta que el pollo esté dorado. 3. Remover para que el pollo se cocine bien, añadir el tomate, el curry, el chile, sal y prejil, mezclar todo y al final añadir la leche de coco. 4. Colocar en un sartén a fuego el doble de agua con arroz, cuando empiece a hervir poner el arroz y dejar por 10 minutos", imagen: UIImage(named: "comidas")!),
       Receta(nombre: "Cenas",tiempo: "Tiempo de preparación: 35 min", platillo: "Pizza de champiñones", ingredientes : "1 pan pita, 4o gramos de queso panela, 1/2 taza de espinacas, 3 champiñones, 8 aceitunas negras. Para la salsa: 1 tomate, ajo en polva y orégano.", preparación: "1. Hacer la salsa licuando un tomate con ajo en polvo y orégano. 2. Dorar en un comal el pan pita y colocar encima la salsa, el queso panela, la espinaca, los champiñones y las aceitunas negras. 3. Tapar hasta que se derrita el queso, salpimentar.", imagen: UIImage(named: "cenas")!),
        Receta(nombre: "Postres",tiempo: "Tiempo de preparación: 15 min", platillo: "Pastel de queso", ingredientes: "1 huevo, 100 gr de yogurt griego, 50 gr de requesón, 1 cucharada de harina o avena molida, 2 sobres de stevia, 3 fresas, blueberries", preparación: "1.Batir 1 huevo y agregar 100 gr de yogurt griego mezclado con el requesón, 2. Agregar la harina o avena molida y stevia, 3. Ponerlo en una taza o recipiente e ingresarlo al microondas y cocinar por 2 minutos, 4. Decorar con la fruta. ", imagen: UIImage(named: "postres")!),
        Receta(nombre: "Snacks",tiempo: "Tiempo de preparación: 10 min", platillo: "Manzanas preparadas", ingredientes: "2 manzanas, 2 cucharaditas de crena de cacahuate natural, 3 cucharadas de granola, 1 cucharada de coco rallado, arándanos, chispas de chocolate", preparación: "1.Cortar en rodajas las manzanas. 2. Agregar la crema de cacahuate natural, granola, coco rallado, arándanos y chispas de chocolate", imagen: UIImage(named: "snack")!),
    
    ]
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return listaRecetas.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celdareceta", for: indexPath) as! TableViewCellReceta
        
        let recetas = listaRecetas[indexPath.row]

        cell.labelNombre.text = recetas.nombre
        cell.labelTiempo.text = recetas.tiempo
        cell.imagenReceta.image = recetas.imagen
        
        
        // Configure the cell...

        return cell
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 130

    
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        RecetaSeleccionada = listaRecetas [indexPath.row]
        performSegue(withIdentifier: "segueRecetasToDetalle", sender: nil)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let siguienteEscena = segue.destination as! ViewControllerProyectoDetalle
        siguienteEscena.RecetaRecibida = RecetaSeleccionada
    
    }
   
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    
    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


}
