//
//  TableViewCellReceta.swift
//  prototipo final
//
//  Created by Laboratorio UNAM-Apple4 on 27/10/22.
//

import UIKit

class TableViewCellReceta: UITableViewCell {

    
    @IBOutlet weak var labelNombre: UILabel!
    
    @IBOutlet weak var labelTiempo: UILabel!
    
    @IBOutlet weak var imagenReceta: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
