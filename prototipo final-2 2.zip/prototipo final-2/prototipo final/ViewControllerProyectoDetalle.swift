//
//  ViewControllerProyectoDetalle.swift
//  prototipo final
//
//  Created by Laboratorio UNAM-Apple4 on 27/10/22.
//
/*
 En esta app lo que se podrá hacer, es conocer y saber como realizar diferentes recetas debido a que muestra ingredientes, tiempo de preparación, y la forma de preparación.
 En la primera escena, se muestra la forma para iniciar sesión o en caso que no posees una cuenta podrás registrar una nueva, siendo esta la segunda escena, la cual pide datos personales del usuario.
 La tercera escena es para que el usuario pueda recuperar su contraseña en dado caso que la haya olvidado, lo único que necesitará es colocar su correo electrónico con el cuál creo su cuenta.
 En la cuarta escena (primer item) se observa una tabla la cual resuelve la primera necesidad del cliente, la cuál es que en ocasiones no sabe qué cocinar en el desayuno o qué tipo de snacks llevarse a la facultad. Al tener el tiempo justo, muestra el tiempo de preparación aproximado de cada platillo.
 En la quinta escena aparecen los ingredientes que se necesitan y la preparación del platillo a elegir. En la parte superior del lado derecho se encuentra un botón (carrito de súper) para que se pueda pedir por delivery aquellos ingredientes con los que no cuenta el cliente. Lo que nos lleva a la sexta escena.
 En la séptima escena (segundo item), fue creada para que facilitara la busqueda de los platillos que se pueden realizar. En esa misma escena está un botón de voz.
 En la octava escena (tercer item) se pueden programar los platillos que desear realizar en la semana, mes, así como la hora en que llegará la notificación. Así como en la escena pasada, también hay un botón voz. Y se muestra la imagén del platillo a realizar. En esta escena también ayuda a la necesidad presentada por el cliente ya que en ocasiones se le olvida lo que anotó en su libreta o en su celular ya que no le llegan notificaciones.
 Lo que nos lleva a la novena escena que es dónde muestra el platillo programado con éxito.
 En la décima escena (cuarto item) se muestra la configuración de la cuenta del usuario. Y un botón por si desea cerrar sesión.
 */

import UIKit

class ViewControllerProyectoDetalle: UIViewController {
 
    var RecetaRecibida : Receta?
    
    @IBOutlet weak var labelDesayuno1: UILabel!
    
    @IBOutlet weak var labelDesayuno2: UILabel!
    

    @IBOutlet weak var labelDesayuno3: UILabel!
    
    @IBOutlet weak var labelDesayuno4: UILabel!
    
   
    
    
    @IBOutlet weak var imagenReceta: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        labelDesayuno1.text = RecetaRecibida?.nombre
        labelDesayuno2.text = RecetaRecibida?.platillo
        labelDesayuno3.text = RecetaRecibida?.ingredientes
        labelDesayuno4.text = RecetaRecibida?.preparación
       
       
        
    }
        // Do any additional setup after loading the view.
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
