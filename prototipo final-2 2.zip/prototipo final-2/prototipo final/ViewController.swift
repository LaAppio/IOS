//
//  ViewController.swift
//  prototipo final
//
//  Created by Laboratorio UNAM-Apple4 on 17/10/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

