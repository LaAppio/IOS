//
//  TableViewCell.swift
//  ESCUELAPROYECTO
//
//  Created by UNAM-Apple8 on 17/10/22.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var imagen: UIImageView!
    
    @IBOutlet weak var etiqueta: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
