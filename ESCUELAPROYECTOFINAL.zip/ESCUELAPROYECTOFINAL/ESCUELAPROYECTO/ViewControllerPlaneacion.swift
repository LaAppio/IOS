//
//  ViewControllerPlaneacion.swift
//  ESCUELAPROYECTO
//
//  Created by Rafael Garfias on 27/11/22.
//

import UIKit

/*
 La información relativa a la "labelMaterial" y "labelEstado" será obtenida de la aplicación web de la escuela y mostrada en la aplicación móvil
 
 */

class ViewControllerPlaneacion: UIViewController {
    
    var profesorRecibido : Planeacion?

    
    @IBOutlet weak var labelNivel: UILabel!
    
    @IBOutlet weak var labelMaterial: UILabel!
    
    @IBOutlet weak var labelEstado: UILabel!
    
    @IBOutlet weak var labelNombre: UILabel!
    
    @IBOutlet weak var imagenProfesor: UIImageView!
    
    @IBOutlet weak var labelHorario: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        labelNombre.text = profesorRecibido?.nombre
        imagenProfesor.image = profesorRecibido?.imagen
        labelNivel.text = profesorRecibido?.nivel
        labelMaterial.text = profesorRecibido?.material
        labelEstado.text = profesorRecibido?.estado
        labelHorario.text = profesorRecibido?.horario
        
        imagenProfesor.layer.cornerRadius = imagenProfesor.bounds.size.width / 2.0
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
