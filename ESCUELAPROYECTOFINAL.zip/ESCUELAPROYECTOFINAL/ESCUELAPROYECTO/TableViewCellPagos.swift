//
//  TableViewCellPagos.swift
//  ESCUELAPROYECTO
//
//  Created by UNAM-Apple8 on 17/10/22.
//

import UIKit


class TableViewCellPagos: UITableViewCell {

    
    @IBOutlet weak var imagen2: UIImageView!
    
    @IBOutlet weak var etiqueta2: UILabel!
    
    
    @IBOutlet weak var labelEstado: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
