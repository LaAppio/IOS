//
//  TableViewControllerPagos.swift
//  ESCUELAPROYECTO
//
//  Created by UNAM-Apple8 on 17/10/22.
//

import UIKit


struct Pagos {
    var imagen : UIImage
    var nombre : String
    var pagos : String
    var deuda : String
    var estado :  String
        
}


class TableViewControllerPagos: UITableViewController {

    var listaalumnos : [Pagos] = [
    Pagos (imagen: UIImage(named: "monica")!, nombre: "Mónica Alcatráz Hernández", pagos: "Diciembre", deuda: "$0.00 pesos", estado: "Al corriente" ),
    Pagos (imagen: UIImage(named: "enrique")!, nombre: "Enrique Ávila Herrera", pagos: "Diciembre", deuda: "$1,000.00 pesos", estado: "Retrasado"),
    Pagos (imagen: UIImage(named: "maria")!, nombre: "Maria Cristina Leiva", pagos: "Diciembre", deuda: "$0.00 pesos", estado: "Al corriente"),
    Pagos (imagen: UIImage(named: "jose")!, nombre: "Jose Alberto Quintana", pagos: "Diciembre", deuda: "$2,000 pesos", estado: "Retrasado"),
    Pagos (imagen: UIImage(named: "reyes")!, nombre: "Maria Reyes Lucena", pagos: "Diciembre", deuda: "$0.00 pesos", estado: "Al corriente"),
    Pagos (imagen: UIImage(named: "antonio")!, nombre: "Antonio Javier Ramirez", pagos: "Diciembre", deuda: "$0.00 pesos", estado: "Al corriente"),
    Pagos (imagen: UIImage(named: "paloma")!, nombre: "Maria Paloma Carrasco", pagos: "Diciembre", deuda: "$500.00 pesos", estado: "Retrasado"),
    Pagos (imagen: UIImage(named: "abraham")!, nombre: "Abraham Chalita Nuñez", pagos: "Diciembre", deuda: "$0.00 pesos", estado: "Al corriente"),
    Pagos (imagen: UIImage(named: "lara")!, nombre: "Lara Gabriela Moreno Laureano", pagos: "Diciembre", deuda: "$700.00 pesos", estado: "Retrasado"),
    Pagos (imagen: UIImage(named: "santiago")!, nombre: "Santiago Velazquez Rodriguez", pagos: "Diciembre", deuda: "$1,400.00 pesos", estado: "Retrasado"),
    Pagos (imagen: UIImage(named: "jimena")!, nombre: "Jimena Guttierez Delgado", pagos: "Diciembre", deuda: "$0.00 pesos", estado: "Al corriente")
    
    ]
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 125
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return listaalumnos.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celdapagos", for: indexPath) as! TableViewCellPagos
        let pago = listaalumnos [indexPath.row]
        cell.etiqueta2.text = pago.nombre
        cell.imagen2.image = pago.imagen
        cell.labelEstado.text = pago.estado
        

        // Configure the cell...

        return cell
    }
    
    var alumnoSeleccionado : Pagos?
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        alumnoSeleccionado = listaalumnos [indexPath.row]
        performSegue(withIdentifier: "seguePagosToDetalle", sender: nil)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "seguePagosToDetalle"{
            
            let siguienteVista = segue.destination as! ViewControllerPagos
            siguienteVista.alumnoRecibido = alumnoSeleccionado
        }
    }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
