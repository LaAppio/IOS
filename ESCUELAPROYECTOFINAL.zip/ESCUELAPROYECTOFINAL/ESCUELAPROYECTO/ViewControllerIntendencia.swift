//
//  ViewControllerIntendencia.swift
//  ESCUELAPROYECTO
//
//  Created by UNAM-Apple8 on 26/10/22.
//
/*
 La información será obtenida de la aplicación web de la escuela y mostrada en la aplicación móvil
 
 */
import UIKit

class ViewControllerIntendencia: UIViewController {
    
    var tareaRecibida : Tareas?
    
    @IBOutlet weak var imagenIntendecia: UIImageView!
    
    @IBOutlet weak var label1: UILabel!
    
    
    @IBOutlet weak var label2: UILabel!
    
    
    
    @IBOutlet weak var label3: UILabel!
    
    
    
    @IBOutlet weak var label4: UILabel!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        label1.text = tareaRecibida?.lugar1
        label2.text = tareaRecibida?.lugar2
        label3.text = tareaRecibida?.lugar3
        label4.text = tareaRecibida?.lugar4
        imagenIntendecia.image = tareaRecibida?.imagen

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
