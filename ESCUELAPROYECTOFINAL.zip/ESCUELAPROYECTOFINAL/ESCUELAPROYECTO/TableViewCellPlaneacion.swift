//
//  TableViewCellPlaneacion.swift
//  ESCUELAPROYECTO
//
//  Created by Rafael Garfias on 27/11/22.
//

import UIKit

class TableViewCellPlaneacion: UITableViewCell {

    
    @IBOutlet weak var imagenplaneacion: UIImageView!
    
    @IBOutlet weak var labelplaneacion: UILabel!
    
    @IBOutlet weak var labelH: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
