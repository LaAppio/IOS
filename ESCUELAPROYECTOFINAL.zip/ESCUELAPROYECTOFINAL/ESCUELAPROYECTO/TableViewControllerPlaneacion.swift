//
//  TableViewControllerPlaneacion.swift
//  ESCUELAPROYECTO
//
//  Created by Rafael Garfias on 27/11/22.
//

import UIKit

struct Planeacion {
    var imagen : UIImage
    var nombre : String
    var nivel : String
    var estado : String
    var material : String
    var horario : String
    
}

class TableViewControllerPlaneacion: UITableViewController {
    
    
    
    var listaprofesores : [Planeacion] = [
        Planeacion(imagen: UIImage(named: "angelica")!, nombre: "Angélica González Martínez", nivel: "Preescolar", estado: "Entregada", material: "Plumones", horario: "9:00 am"),
        Planeacion(imagen: UIImage(named: "romina")!, nombre: "Romina Leon Pérez", nivel: "Preescolar", estado: "Entregada", material: "Gises", horario: "9:30 am"),
        Planeacion(imagen: UIImage(named: "carol")!, nombre: "Carol Jiménez Sánchez", nivel: "Preescolar", estado: "Retrasada", material: "Sin definir", horario: "10:00 am"),
        Planeacion(imagen: UIImage(named: "angel")!, nombre: "Angel Pérez Rangel", nivel: "Primaria", estado: "Entregada", material: "Ninguno", horario: "8:00 am"),
        Planeacion(imagen: UIImage(named: "cristal")!, nombre: "Cristal Estrada Domínguez", nivel: "Primaria", estado: "Retrasada", material: "Sin definir", horario: "8:20 am"),
        Planeacion(imagen: UIImage(named: "fernanda")!, nombre: "Fernanda Rojas Quesada", nivel: "Primaria", estado: "Entregada", material: "Lápices y hojas de color", horario: "11:00 am"),
        Planeacion(imagen: UIImage(named: "sofia")!, nombre: "Sofía Torres Camacho", nivel: "Primaria", estado: "Entregada", material: "Plumones y cartulinas", horario: "11:45 am"),
        Planeacion(imagen: UIImage(named: "israel")!, nombre: "Israel González González", nivel: "Primaria", estado: "Retrasada", material: "Sin definir", horario: "8:45 am"),
        Planeacion(imagen: UIImage(named: "lola")!, nombre: "Lola Nava Nuñez", nivel: "Primaria", estado: "Entregada", material: "Papel crepé y resistol", horario: "11:20 am")

    ]
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 125
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return listaprofesores.count
    }
    
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celdaplaneacion", for: indexPath) as! TableViewCellPlaneacion
        let planeacion = listaprofesores [indexPath.row]
        cell.labelplaneacion.text = planeacion.nombre
        cell.imagenplaneacion.image = planeacion.imagen
        cell.labelH.text = planeacion.horario
        
        
        // Configure the cell...
        
        return cell
        
    }
    var profesorSeleccionado : Planeacion?
    
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        profesorSeleccionado = listaprofesores [indexPath.row]
        performSegue(withIdentifier: "seguePlaneacionToDetalle", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "seguePlaneacionToDetalle"{
            let siguienteVista = segue.destination as!
            ViewControllerPlaneacion
            siguienteVista.profesorRecibido = profesorSeleccionado
        }
        
    }
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
}
