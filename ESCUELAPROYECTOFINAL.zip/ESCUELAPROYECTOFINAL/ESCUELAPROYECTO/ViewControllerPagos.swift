//
//  ViewControllerPagos.swift
//  ESCUELAPROYECTO
//
//  Created by UNAM-Apple8 on 26/10/22.
//
/*
 La información relativa a la "labelaPagos", "labelDeuda" y "labelEstado" será obtenida de la aplicación web de la escuela y mostrada en la aplicación móvil
 */

import UIKit

class ViewControllerPagos: UIViewController {
    
    var alumnoRecibido : Pagos?
    
    
    @IBOutlet weak var labelaPagos: UILabel!
    
    @IBOutlet weak var labelDeuda: UILabel!
    
    
    @IBOutlet weak var labelEstado: UILabel!
    
    @IBOutlet weak var imagenPagos: UIImageView!
    
    @IBOutlet weak var labelNombre: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        labelDeuda.text = alumnoRecibido?.deuda
        labelEstado.text = alumnoRecibido?.estado
        labelaPagos.text = alumnoRecibido?.pagos
        imagenPagos.image = alumnoRecibido?.imagen
        labelNombre.text = alumnoRecibido?.nombre
        imagenPagos.layer.cornerRadius = imagenPagos.bounds.size.width / 2.0
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
