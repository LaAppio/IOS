//
//  TableViewController.swift
//  ESCUELAPROYECTO
//
//  Created by UNAM-Apple8 on 17/10/22.
//

import UIKit

struct Tareas {
    var imagen : UIImage
    var nombre : String
    var lugar1 : String
    var lugar2 : String
    var lugar3 : String
    var lugar4 : String
    
}

class TableViewController: UITableViewController {

    var listatareas : [Tareas] = [
    Tareas (imagen: UIImage (named: "barrer")!, nombre: "Barrer intalaciones", lugar1: "Salones", lugar2: "Oficinas", lugar3: "Baños", lugar4: "Patio escolar"),
    Tareas (imagen: UIImage (named: "trapear")!, nombre: "Trapear intalaciones", lugar1: "Salones", lugar2: "Oficinas", lugar3: "Baños", lugar4: "Patio escolar"),
    Tareas (imagen: UIImage (named: "ventana")!, nombre: "Limpiar las ventanas", lugar1: "Salones", lugar2: "Oficinas", lugar3: "Baños", lugar4: "Cocina"),
    Tareas (imagen: UIImage (named: "baño")!, nombre: "Lavar los baños", lugar1: "Niños", lugar2: "Niñas", lugar3: "Maestros", lugar4: "Dirección"),
    Tareas (imagen: UIImage (named: "basura")!, nombre: "Sacar la basura", lugar1: "Salones", lugar2: "Oficinas", lugar3: "Baños", lugar4: "Patio escolar")

    ]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 125
        
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return listatareas.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! TableViewCell
        let tareas = listatareas [indexPath.row]
        cell.etiqueta.text = tareas.nombre
        cell.imagen.image = tareas.imagen
        
        

        // Configure the cell...

        return cell
    }
    
    var tareaSeleccionada : Tareas?
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tareaSeleccionada = listatareas [indexPath.row]
        performSegue(withIdentifier: "segueIntendeciaToDetalle", sender: nil)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let siguienteVista = segue.destination as! ViewControllerIntendencia
        siguienteVista.tareaRecibida = tareaSeleccionada
        
    }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
